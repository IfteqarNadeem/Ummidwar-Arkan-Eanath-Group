# Caring Connection Android Test App

This is an Android Studio project that wraps the working Caring Connection app
into a normal Android application using a WebView.

## What works
- App icon and normal Android launcher
- Full-screen app experience
- Members
- Monthly collections
- Donations
- Help / expense entries
- Ledger
- Reports
- Local on-device storage through WebView localStorage
- Offline operation after installation

## Build the APK in Android Studio
1. Install Android Studio on Windows/Mac.
2. Extract this ZIP.
3. Open the `CaringConnection_AndroidStudio` folder.
4. Let Android Studio download/sync Gradle dependencies.
5. Choose: Build > Build App Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will normally be created at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Copy that APK to your Android phone and install it.

If Android blocks installation, enable "Install unknown apps" for the app you
used to open the APK (for example Files or Chrome).

## Important
This is a local test build. It does NOT yet have:
- Cloud database
- Multiple users
- Admin/Treasurer permissions
- Server-side backup
- Secure authentication

Those should be added before real foundation use.


## v0.3 PDF fix
The report PDF button is now connected to Android's native print service.
Tap **Download / Save PDF**, choose **Save as PDF**, then tap the save/PDF icon.


## v0.4 transaction safety update
- Edit previously recorded member collection amounts from the Ledger.
- Delete mistaken/duplicate transactions from the Ledger with confirmation.
- Collection entry now shows a confirmation popup before saving.
- If the member already has a collection in the same month, the confirmation warns about the existing amount.
- Member deletion has a stronger confirmation message.
- Added Reset All App Data with two-step confirmation (`RESET` must be typed).
